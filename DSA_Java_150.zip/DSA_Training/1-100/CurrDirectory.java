public class CurrDirectory {

    public static void main(String[] args) {

        String path = System.getProperty("user.dir");
        
        System.out.println("Working Directory = " + path);

    }
}
/*
 Working Directory = C:\Users\rohit\OneDrive\Desktop\DSA_Training
 */