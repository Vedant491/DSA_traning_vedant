class StrToInt {
  public static void main(String[] args) {

    // create string variables
    String str1 = "23";
    String str2 = "4566";

    // convert string to int
    // using parseInt()
    int num1 = Integer.parseInt(str1);
    int num2 = Integer.parseInt(str2);

    // print int values
    System.out.println(num1);    // 23
    System.out.println(num2);    // 4566
  }
}
/*
23
4566
 */