class LongToInt {
  public static void main(String[] args) {

    // create long variables
    long a = 2322331L;
    long b = 52341241L;

    // convert long into int
    // using typecasting
    int c = (int)a;
    int d = (int)b;

    System.out.println(c);    // 2322331
    System.out.println(d);    // 52341241
  }
}
/*
2322331
52341241
 */