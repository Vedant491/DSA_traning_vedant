class UpperCase {
  public static void main(String[] args) {
    char c;
    for(c = 'A'; c <= 'Z'; ++c)
      System.out.print(c + " ");
    }
}
/*
A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
 */