class Pow{
  public static void main(String[] args) {
    int base = 3, exponent = -4;
    double result = Math.pow(base, exponent);
    System.out.println("Answer = " + result);
  }
}
/*
 Answer = 0.012345679012345678
 */