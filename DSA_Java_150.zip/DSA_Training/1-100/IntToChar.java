class IntToChar {
  public static void main(String[] args) {

    // create int variables
    int num1 = 80;
    int num2 = 81;

    // convert int to char
    // typecasting
    char a = (char)num1;
    char b = (char)num2;

    // print value
    System.out.println(a);    // P
    System.out.println(b);    // Q
  }
}
/*
P
Q
 */